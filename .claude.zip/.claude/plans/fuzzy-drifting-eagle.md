# 주식 포트폴리오 시뮬레이터 웹앱 계획

## 프로젝트 개요

사용자가 ETF를 선택하여 포트폴리오를 구성하고, 백테스트를 통해 QQQ, SPY와 성과를 비교하는 웹앱

---

## 1. 핵심 기능

### 1.1 포트폴리오 구성
- ETF 검색 및 추가
- 비중(%) 설정
- 포트폴리오 저장/불러오기

### 1.2 백테스트 시뮬레이션
- 기간 설정 (시작일 ~ 종료일)
- 초기 투자금 설정
- 리밸런싱 주기 설정 (월별/분기별/연별)
- **단순 비중 유지 방식** (배당 재투자 미포함)

### 1.3 성과 비교
- QQQ, SPY 벤치마크 대비 비교
- 수익률 차트 (라인 그래프)
- 주요 지표: CAGR, MDD, Sharpe Ratio, Volatility

---

## 2. 기술 스택 (확정)

### Frontend
- **React + Vite + TypeScript**
- **Recharts**: 차트 시각화
- **Tailwind CSS**: 스타일링
- **localStorage**: 포트폴리오 저장 (인증 없음)

### Backend
- **FastAPI (Python)**: REST API
- **pandas**: 데이터 처리 및 백테스트 계산
- **yfinance**: 주가 데이터 수집

### 데이터 소스
- **yfinance** (무료, Yahoo Finance 비공식 API)

---

## 3. UI 구성

```
┌─────────────────────────────────────────────────────────────┐
│  📈 Portfolio Backtester                              [Login]│
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────────┐  ┌──────────────────────────────────┐ │
│  │ 포트폴리오 구성   │  │          성과 차트               │ │
│  │                  │  │                                  │ │
│  │ [ETF 검색...]    │  │    📈 [라인 차트]                │ │
│  │                  │  │    - 내 포트폴리오 (파랑)        │ │
│  │ ┌──────────────┐ │  │    - QQQ (빨강)                 │ │
│  │ │ QQQ    30%   │ │  │    - SPY (초록)                 │ │
│  │ │ SCHD   25%   │ │  │                                  │ │
│  │ │ VTI    25%   │ │  └──────────────────────────────────┘ │
│  │ │ BND    20%   │ │                                       │
│  │ └──────────────┘ │  ┌──────────────────────────────────┐ │
│  │                  │  │        성과 지표                 │ │
│  │ 합계: 100%       │  │ ┌────────┬────────┬────────────┐ │ │
│  └──────────────────┘  │ │        │ 내 PF  │ QQQ │ SPY  │ │ │
│                        │ ├────────┼────────┼────────────┤ │ │
│  ┌──────────────────┐  │ │ CAGR   │ 12.5%  │ 15% │ 10%  │ │ │
│  │ 시뮬레이션 설정   │  │ │ MDD    │ -20%   │-33% │ -25% │ │ │
│  │                  │  │ │ Sharpe │ 1.2    │ 0.9 │ 1.0  │ │ │
│  │ 시작일: 2020-01  │  │ │ Vol    │ 15%    │ 22% │ 18%  │ │ │
│  │ 종료일: 2024-12  │  │ └────────┴────────┴────────────┘ │ │
│  │ 초기금: $10,000  │  └──────────────────────────────────┘ │
│  │ 리밸런싱: 분기별 │                                       │
│  │                  │                                       │
│  │ [시뮬레이션 실행] │                                       │
│  └──────────────────┘                                       │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. API 설계

### 4.1 ETF 검색
```
GET /api/etf/search?q={keyword}
Response: [{ symbol, name, expense_ratio }]
```

### 4.2 백테스트 실행
```
POST /api/backtest
Body: {
  portfolio: [{ symbol: "QQQ", weight: 0.3 }, ...],
  start_date: "2020-01-01",
  end_date: "2024-12-01",
  initial_amount: 10000,
  rebalance: "quarterly"
}
Response: {
  portfolio_values: [...],
  benchmarks: { QQQ: [...], SPY: [...] },
  metrics: { cagr, mdd, sharpe, volatility }
}
```

### 4.3 ETF 가격 데이터
```
GET /api/etf/{symbol}/history?start={date}&end={date}
Response: [{ date, close, adjusted_close }]
```

---

## 5. 프로젝트 구조

```
stock-portfolio-simulator/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── PortfolioBuilder.tsx
│   │   │   ├── ETFSearch.tsx
│   │   │   ├── PerformanceChart.tsx
│   │   │   ├── MetricsTable.tsx
│   │   │   └── SimulationSettings.tsx
│   │   ├── hooks/
│   │   │   └── useBacktest.ts
│   │   ├── types/
│   │   │   └── index.ts
│   │   └── App.tsx
│   └── package.json
│
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── routers/
│   │   │   ├── etf.py
│   │   │   └── backtest.py
│   │   ├── services/
│   │   │   ├── data_fetcher.py
│   │   │   └── backtest_engine.py
│   │   └── models/
│   │       └── schemas.py
│   └── requirements.txt
│
├── docs/
│   └── prd/
│       └── portfolio-simulator.md
│
└── README.md
```

---

## 6. 구현 단계 (Agentic Workflow 기반)

### Phase 1: 요구사항 분석
- 데이터 소스 선정 (yfinance)
- 백테스트 로직 정의
- UI/UX 확정

### Phase 2: PRD 작성
- 기능 명세서 작성
- API 스펙 정의
- 테스트 계획 수립

### Phase 3: TDD - 테스트 먼저
- 백테스트 엔진 테스트
- API 엔드포인트 테스트
- 컴포넌트 테스트

### Phase 4: 구현
1. Backend: FastAPI + yfinance 데이터 수집
2. Backend: 백테스트 엔진 구현
3. Frontend: React 컴포넌트 구현
4. Frontend: 차트 및 UI 완성
5. 통합

### Phase 5: 테스트 실행
- 단위 테스트
- 통합 테스트
- E2E 테스트

### Phase 6: 코드 리뷰
- 보안, 성능, 품질 검토

### Phase 7: 문서화 및 배포
- README 작성
- 배포 (Vercel + Railway/Render)

---

## 7. 확정된 사항

| 항목 | 결정 |
|------|------|
| 데이터 소스 | yfinance (무료) |
| 사용자 인증 | 없음 (localStorage 사용) |
| 리밸런싱 방식 | 단순 비중 유지 |
| 프론트엔드 | React + Vite |
| 벤치마크 | QQQ, SPY |

---

## 8. 프로젝트 시작 위치

새 프로젝트 폴더: `C:\Users\User\stock-portfolio-simulator\`
