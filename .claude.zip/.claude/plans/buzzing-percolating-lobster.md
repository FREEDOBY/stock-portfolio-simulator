# PDF to Markdown Splitter - Implementation Plan

## Overview
PDF 파일의 **북마크/목차(섹션 정보)**를 읽어서 섹션별로 **마크다운(md) 파일**로 분절하는 GUI 도구

## 핵심 기능

### 1. PDF 섹션 감지
- PDF 북마크(outline/TOC) 읽기
- 각 섹션의 페이지 범위 파악
- 섹션 계층 구조 인식 (1장 > 1.1절 > 1.1.1항)

### 2. 마크다운 변환
- 텍스트 추출 및 마크다운 형식 변환
- 표(table) 추출 → 마크다운 테이블로 변환
- 섹션 제목을 마크다운 헤딩(#, ##)으로 변환

### 3. 출력
- 섹션별 개별 md 파일 생성
- 파일명: 섹션 이름 기반 (예: `01_서론.md`, `02_본론.md`)
- 섹션 없는 PDF: 전체를 하나의 md로 변환

### 4. GUI
- PDF 파일 선택
- 섹션 목록 표시 (체크박스로 선택 가능)
- 출력 폴더 선택
- 변환 실행

## 기술 스택

| 구성요소 | 라이브러리 | 이유 |
|---------|-----------|------|
| PDF 처리 | PyMuPDF (fitz) | 북마크, 텍스트, 표 추출 모두 지원 |
| GUI | tkinter | Python 내장, 설치 불필요 |

## 프로젝트 구조

```
C:\PDFsplitter\
├── main.py                 # 진입점
├── gui/
│   ├── __init__.py
│   └── app.py              # GUI 메인 윈도우
├── core/
│   ├── __init__.py
│   ├── pdf_reader.py       # PDF 읽기, 섹션 파싱
│   └── md_converter.py     # 마크다운 변환
├── requirements.txt
└── README.md
```

## 구현 단계

### Step 1: 프로젝트 초기화
- 폴더 구조 생성
- requirements.txt 작성 (`PyMuPDF`)

### Step 2: PDF 읽기 모듈 (core/pdf_reader.py)
- `get_sections(pdf_path)` → 섹션 목록 반환
  - 반환: `[{title, level, start_page, end_page}, ...]`
- `extract_text(pdf_path, start_page, end_page)` → 텍스트 추출
- `extract_tables(pdf_path, start_page, end_page)` → 표 추출

### Step 3: 마크다운 변환 모듈 (core/md_converter.py)
- `text_to_markdown(text)` → 기본 텍스트 변환
- `table_to_markdown(table_data)` → 표를 md 테이블로
- `convert_section(section, text, tables)` → 섹션을 md로 변환

### Step 4: GUI 구현 (gui/app.py)
- PDF 파일 선택 버튼
- 섹션 목록 표시 (Listbox/Treeview)
- 출력 폴더 선택
- 변환 버튼 및 진행률 표시

### Step 5: 통합 (main.py)
- 전체 연결 및 테스트

## GUI 와이어프레임

```
┌──────────────────────────────────────────────┐
│  PDF → Markdown Splitter               [X]  │
├──────────────────────────────────────────────┤
│                                              │
│  PDF 파일: [________________] [찾아보기]     │
│                                              │
│  ─────────── 감지된 섹션 ───────────         │
│  ┌──────────────────────────────────────┐   │
│  │ ☑ 1. 서론                    (p.1-5)  │   │
│  │ ☑ 2. 본론                    (p.6-20) │   │
│  │   ☑ 2.1 방법론              (p.6-10) │   │
│  │   ☑ 2.2 결과                (p.11-20)│   │
│  │ ☑ 3. 결론                   (p.21-25)│   │
│  └──────────────────────────────────────┘   │
│  [전체 선택] [전체 해제]                     │
│                                              │
│  출력 폴더: [_______________] [찾아보기]     │
│                                              │
│  [=========== 진행률 ===========]            │
│                                              │
│              [ 변환 시작 ]                   │
│                                              │
│  상태: 3/5 섹션 변환 완료                    │
└──────────────────────────────────────────────┘
```

## 출력 예시

입력: `논문.pdf` (섹션: 서론, 본론, 결론)

출력:
```
output_folder/
├── 01_서론.md
├── 02_본론.md
└── 03_결론.md
```

각 md 파일 내용:
```markdown
# 서론

이 연구는...

| 항목 | 값 |
|-----|-----|
| A | 100 |
| B | 200 |
```
