- PyPI에서 설치
pipx install superclaude

# 명령어 설치 (30개의 슬래시 명령어 설치)
superclaude install

# MCP 서버 설치 (선택사항)
superclaude mcp --list        # 사용 가능한 MCP 서버 목록
superclaude mcp --servers tavily context7  # 특정 서버 설치 이거 진행하는데 필요한게 있으면 너가 알아서 다 설치하고 되게해